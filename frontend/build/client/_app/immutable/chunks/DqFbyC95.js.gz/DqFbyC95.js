import{m as o,E as f,n as i,o as p,q as c,l as d,v as h}from"./TlERTnYi.js";function v(s,e,...t){var r=s,n=p,a;o(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=i(()=>n(r,...t)))},f),d&&(r=h)}export{v as s};
